//
//  EyesImage.m
//  LittleYellowMan
//
//  Created by ChangRJey on 2017/7/14.
//  Copyright © 2017年 RenJiee. All rights reserved.
//

#import "EyesImage.h"

@implementation EyesImage

@synthesize collisionBoundsType;


@end
